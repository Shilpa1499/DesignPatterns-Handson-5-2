package com.cts.singleton;

public class Test {

	public static void main(String[] args) {
		DBConn dBConn = DBConn.getInstance();
		System.out.println(dBConn.getClass());
	}
	
}
