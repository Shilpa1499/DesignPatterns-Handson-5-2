package com.cts.mercedes;
import com.cts.abstractclasses.Tire;

public class MercedesTire extends Tire {

}
