package com.cts.mercedes;

import com.cts.abstractclasses.HeadLight;

public class MercedesHeadlight  extends HeadLight{

}
