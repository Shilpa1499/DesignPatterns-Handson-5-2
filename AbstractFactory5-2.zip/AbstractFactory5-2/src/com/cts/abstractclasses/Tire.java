package com.cts.abstractclasses;

public abstract class Tire {

}
