package com.cts.abstractclasses;

public abstract class HeadLight {

}
