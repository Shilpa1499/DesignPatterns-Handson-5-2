package com.cts.audi;
import com.cts.abstractclasses.HeadLight;

public class AudiHeadlight extends HeadLight {

}
