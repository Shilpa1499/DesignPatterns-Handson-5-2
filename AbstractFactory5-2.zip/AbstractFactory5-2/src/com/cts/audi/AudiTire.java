package com.cts.audi;

import com.cts.abstractclasses.Tire;

public class AudiTire extends Tire{

}
